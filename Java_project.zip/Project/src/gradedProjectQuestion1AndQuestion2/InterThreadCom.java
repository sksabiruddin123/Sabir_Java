package gradedProjectQuestion1AndQuestion2;

import java.io.*;
import java.util.*;

class Thread1 extends Thread {
    private Map<Project, ArrayList<Employee>> projectMap;
    private volatile boolean serialized = false;
    
    public Thread1(Map<Project, ArrayList<Employee>> projectMap) {
        this.projectMap = projectMap;
    }

    public Map<Project, ArrayList<Employee>> getProjectMap() {
        return projectMap;
    }

    public void run() {
        // Implement Serialization logic here
        synchronized (this) {
            System.out.println("Serialize called by Producer");
            try {
                ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("serializedData.ser"));
                oos.writeObject(projectMap);
                oos.close();
                
                serialized = true;
            } catch (IOException e) {
                e.printStackTrace();
            }
            this.notifyAll(); // Notify waiting threads (consumers)
        }

        // Wait for the other thread to complete Deserialization
        synchronized (this) {
        	while (!serialized) {
                try {
                    this.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }

        // Implement Deserialization logic here
        synchronized (this) {
            System.out.println("DeSerialize Called by Consumer");
            try {
                ObjectInputStream ois = new ObjectInputStream(new FileInputStream("serializedData.ser"));
                @SuppressWarnings("unchecked")
                Map<Project, ArrayList<Employee>> deserializedMap = (Map<Project, ArrayList<Employee>>) ois.readObject();
                ois.close();

                for (Map.Entry<Project, ArrayList<Employee>> entry : deserializedMap.entrySet()) {
                    Project project = entry.getKey();
                    ArrayList<Employee> employees = entry.getValue();

                    System.out.println("The Project\n" + project + " Has the following Employees");
                    System.out.println("Employees .............");
                    for (Employee employee : employees) {
                        System.out.println(employee);
                    }
                }
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }
}

class producer extends Thread {
    private Thread1 thread;

    public producer(Thread1 thread) {
        this.thread = thread;
    }

    public void run() {
        synchronized (thread) {
            try {
                // Start the serialization thread
                thread.start();

                // Wait for the serialization to complete
                thread.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            thread.notifyAll();
        }
    }
}

class consumer extends Thread {
    private Thread1 thread;

    public consumer(Thread1 thread) {
        this.thread = thread;
    }

    public void run() {
        synchronized (thread) {
            // Notify the serialization thread to start deserialization
            thread.notify();

            // Wait for deserialization to complete
            try {
                thread.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

public class InterThreadCom {
    public static void main(String[] args) {
        Project project1 = new Project("P1", "Music Synthesizer", 23);
        Project project2 = new Project("P2", "Vehicle Movement Tracker", 13);
        Project project3 = new Project("P3", "Liquid Viscosity Finder", 15);

        ArrayList<Employee> eList1 = new ArrayList<>();
        ArrayList<Employee> eList2 = new ArrayList<>();
        ArrayList<Employee> eList3 = new ArrayList<>();

        Employee e1 = new Employee("E001", "Harsha", "9383993933", "RTNagar", 1000);
        Employee e2 = new Employee("E002", "Harish", "9354693933", "Jayanagar", 2000);
        Employee e3 = new Employee("E003", "Meenal", "9383976833", "Malleswaram", 1500);
        eList1.add(e1);
        eList1.add(e2);
        eList1.add(e3);

        Employee e4 = new Employee("E004", "Sundar", "9334593933", "Vijayanagar", 3000);
        Employee e5 = new Employee("E005", "Suman", "9383678933", "Indiranagar", 2000);
        Employee e6 = new Employee("E006", "Suma", "9385493933", "KRPuram", 1750);
        eList2.add(e4);
        eList2.add(e5);
        eList2.add(e6);

        Employee e7 = new Employee("E007", "Chitra", "9383978933", "Koramangala", 4000);
        Employee e8 = new Employee("E008", "Suraj", "9383992133", "Malleswaram", 3000);
        Employee e9 = new Employee("E009", "Manu", "9345193933", "RTNagar", 2000);
        eList3.add(e7);
        eList3.add(e8);
        eList3.add(e9);
        
        Map<Project, ArrayList<Employee>> projectMap = new HashMap<>();
        projectMap.put(project1, eList1);
        projectMap.put(project2, eList2);
        projectMap.put(project3, eList3);

        Thread1 obj1 = new Thread1(projectMap);
        Thread1 obj2 = new Thread1(projectMap);
        Thread1 obj3 = new Thread1(projectMap);

        producer p1 = new producer(obj1);
        consumer c1 = new consumer(obj1);

        producer p2 = new producer(obj2);
        consumer c2 = new consumer(obj2);

        producer p3 = new producer(obj3);
        consumer c3 = new consumer(obj3);

        p1.start();
        c1.start();

        p2.start();
        c2.start();

        p3.start();
        c3.start();
    }
}