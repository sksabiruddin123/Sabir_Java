package gradedProjectQuestion1AndQuestion2;

import java.io.Serializable;

public class Employee implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String EmployeeId;
	private String EmployeeName;
	private String EmployeePhoneNumber;
	private String EmployeeAddress;
	private int EmployeeSalary;
	
	
	public Employee(String employeeId, String employeeName, String employeePhoneNumber, String employeeAddress,
			int employeeSalary) {
		EmployeeId = employeeId;
		EmployeeName = employeeName;
		EmployeePhoneNumber = employeePhoneNumber;
		EmployeeAddress = employeeAddress;
		EmployeeSalary = employeeSalary;
	}

	public String getEmployeeId() {
		return EmployeeId;
	}

	public void setEmployeeId(String employeeId) {
		EmployeeId = employeeId;
	}

	public String getEmployeeName() {
		return EmployeeName;
	}

	public void setEmployeeName(String employeeName) {
		EmployeeName = employeeName;
	}

	public String getEmployeePhoneNumber() {
		return EmployeePhoneNumber;
	}

	public void setEmployeePhoneNumber(String employeePhoneNumber) {
		EmployeePhoneNumber = employeePhoneNumber;
	}

	public String getEmployeeAddress() {
		return EmployeeAddress;
	}

	public void setEmployeeAddress(String employeeAddress) {
		EmployeeAddress = employeeAddress;
	}

	public int getEmployeeSalary() {
		return EmployeeSalary;
	}

	public void setEmployeeSalary(int employeeSalary) {
		EmployeeSalary = employeeSalary;
	}

	@Override
	public String toString() {
		return "Employee [EmployeeId=" + EmployeeId + ", EmployeeName=" + EmployeeName + ", EmployeePhoneNumber="
				+ EmployeePhoneNumber + ", EmployeeAddress=" + EmployeeAddress + ", EmployeeSalary=" + EmployeeSalary
				+ "]";
	}

	
	
	
}
