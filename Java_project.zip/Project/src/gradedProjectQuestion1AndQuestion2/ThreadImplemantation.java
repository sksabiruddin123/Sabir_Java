package gradedProjectQuestion1AndQuestion2;

import java.util.ArrayList;
import java.util.Map;

public class ThreadImplemantation {
	public static void main(String[] args) {
        ProjectSerializer projectSerializer = new ProjectSerializer();
        ProjectDeSerializer projectDeSerializer = new ProjectDeSerializer();
        
        Map<Project, ArrayList<Employee>> projectMap = projectSerializer.projectMap1;
        
        Thread serializationThread = new Thread(() -> {
             projectSerializer.serializeProjectDetails(projectMap);
        });

        Thread deserializationThread = new Thread(() -> {
        	projectDeSerializer.deserializeProjectDetails();
        });
        serializationThread.start();
        deserializationThread.start();

        try {
            serializationThread.join();
            deserializationThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Main thread exiting.");
    }
}
