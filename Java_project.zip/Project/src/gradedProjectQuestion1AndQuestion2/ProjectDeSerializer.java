package gradedProjectQuestion1AndQuestion2;

import java.io.*;
import java.util.*;

public class ProjectDeSerializer {
	
	@SuppressWarnings("unchecked")
	public void deserializeProjectDetails() {
        try {
        	ObjectInputStream ois = new ObjectInputStream(new FileInputStream("C:/Users/Lenovo/eclipse-workspace/Project/serializedData.ser"));
			Map<Project, ArrayList<Employee>> deserializedMap = (Map<Project, ArrayList<Employee>>) ois.readObject();
            ois.close();

            System.out.println("DeSerialized Data :");
            for (Map.Entry<Project, ArrayList<Employee>> entry : deserializedMap.entrySet()) {
                Project project = entry.getKey();
                ArrayList<Employee> employees = entry.getValue();

                System.out.println("The Project\n" + project + " Has the following Employees");
                System.out.println("Employees .............");
                for (Employee employee : employees) {
                    System.out.println(employee);
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

}
