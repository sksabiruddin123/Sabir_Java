package gradedProjecfQuestion3;

import java.util.Arrays;

public class SumOfSquaresOfNumbers {
	
	public static void main(String [] args)
	{
		int [] arr = {1,2,3,4,5};
		
		int[] oddNumbersSquared = Arrays.stream(arr)
                .filter(num -> num % 2 != 0)
                .map(num -> num * num)
                .toArray();

//        System.out.print("ODD NUMBERS: [ ");
//        Arrays.stream(arr)
//                .filter(num -> num % 2 != 0)
//                .forEach(num -> System.out.print(num + " "));
//        System.out.println("]");
//        System.out.println("SQUARES: " + Arrays.toString(oddNumbersSquared));

		int sum = Arrays.stream(oddNumbersSquared).sum();
        System.out.println("SUM: " + sum);
	}
}
